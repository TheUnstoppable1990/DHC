# Dope Holiday Cards (DHC)
-------------------------------
This is a BepInEx compatible mod for ROUNDS that adds a few cards to the game.

Thank you to everyone in the ROUNDS modding community, who helped me, especially Pykess, Ascyst and Willis.

## Easy Installation Instructions
---------------------------------

Download [r2modman](https://rounds.thunderstore.io/package/ebkr/r2modman/), set up a Rounds profile, and add `HDC` to the profile. All dependencies will be automatically installed. Just click `Start Modded` to start playing!

## Cards Added
-------------

### Christmas Day

-----------------

-Gives you a rare card for every player and also gives every other a rare card as well

### Hanukkah

-----------------

-Gives you 8 random common cards, depending on what they are that could be great or like socks or something.

### Kwanzaa

-----------------

-Gives you 7 Kwanzaa based common cards, adding up to one powerful rare card IMHO

### Version Notes

-----------------

### v0.1.0

----------

-Happy Holidays Everyone